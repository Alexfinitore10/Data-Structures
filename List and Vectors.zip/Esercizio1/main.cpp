
#include "zlasdtest/test.hpp"
#include "list/list.hpp"
#include "vector/vector.hpp"

#include "zmytest/test.hpp"

/* ************************************************************************** */

#include<iostream>

/* ************************************************************************** */

int main() {
  //lasdtest(); // To call in the menu of your library test!
  Hub();
  return 0;
}
