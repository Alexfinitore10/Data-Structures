
#ifndef MYTEST_HPP
#define MYTEST_HPP

#include"../zlasdtest/test.hpp"
#include"../list/list.hpp"
#include"../vector/vector.hpp"


/* ************************************************************************** */

void Menu();
void Hub();

/* ************************************************************************** */

#endif
